class DynamicItem{
  String? key;
  Map<String, dynamic>? dataMap;

  DynamicItem({
    this.key,
    this.dataMap,
  });
}